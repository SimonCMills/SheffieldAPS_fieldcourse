## Partial script for plotting your point-count data

# packages
library(ggplot2); library(dplyr)

# this runs a script that will reformat your data from wide-format to long-format
# for plotting, create a data summary table, and also loads a function to use later. 
source("code/data_formatting.R")

# This should have opened a new tab called 'data_wideformat'. Does it look 
# as you expect? Note that if you are getting error messages at this stage it is 
# probably because you have either (a) made entries in cells where there should 
# be none, (b) entered characters into the columns that should only have numbers, 
# (c) made entries outside of the columns and rows provided, or (d) haven't saved 
# your data table as completed_datatable.csv into the "files" directory. If this 
# happens you will need to go back and edit your dataframe, resave it, and try again. 

# Note that there are now two other dataframes loaded into R: 
# (1) A data_summary table that summarises the number of individuals and species 
# per point
#
# (2) A long-format dataframe, data_longformat, that is just the data you have 
# entered, but converted from wide-format to longformat (which is the format that 
# you need your data in to work with it in R. As with the data you have entered, 
# contains the id of each species observed on each point, and the number of 
# individuals you heard of that species, but all the NAs have been removed and 
# observations are now stacked row-wise, rather than across columns. 
#
# These two dataframes contain all the information you need for the tasks. 

## Tasks
# task 1: what is the average number of species on a point in each habitat? 


# task2: produce plot of point-level species richness by habitat type
# e.g. histogram, dotplot, points (+ horizontal jittering)


# task 3: how many species do you observe in total in each different habitat type?
# note: you will need to refer back to your data_longformat table here


# task 4: are there more species in one habitat vs the other than we would expect
# by chance? To do this we need to plot rarefaction curves for your samples

# calculate rarefaction curves
# calculate_rcurve is a function that I have written for you: it will
# return a dataframe of number of individuals sampled ("m" column) and the 
# expected species richness in this sample ("S_exp" column), as well as some upper
# and lower (95%) bounds on this, 'upr', and 'lwr,.
preds_forest <- calculate_rcurve(data_longformat, habitat_type = "Forest")  
preds_pasture <- calculate_rcurve(data_longformat, habitat_type = "Pasture")  
# bind your predictions for pasture and forest together into a single dataframe
preds_both <- bind_rows(preds_forest, preds_pasture)

# plot these rarefaction curves


