## Partial script for summarising and plotting your point-count data
##
## You need to change the file name to wherever you have saved your data file 
## and then just run the whole script to format your data from the format you 
## entered it in (wide-format) to a useful long-format summary for plotting. 
##
## Note: you can set your working directory using setwd("..."), where "..." is the 
## directory you want to read files from, or, equivalently, find it manually via 
## the Session > Set working directory > Choose directory tabs in RStudio

# packages
library(ggplot2); library(dplyr)

# this is loading a function that is provided in another R script. You don't 
# need to understand the technical details of this, but feel free to look at it
# if of interest
source("code/functions.R")

## (1) read in csv file (wide-format)
dat_wf <- read.csv("files/completed_datatable.csv", header = T, 
                   colClasses = c(rep("integer", 11), "character")) %>% 
    as_tibble

# Check it: does it look like you expect? If you are getting errors at this stage
# it is because you have made entries in cells where there should be none, you have
# entered characters into the columns that should only have numbers, or 
# you have made entries outside of the columns and rows provided. If this happens
# you will need to go back and edit your dataframe, resave it, and try again. 
View(dat_wf)

# convert to a long-format dataframe (note: this is a function I have written 
# for you, that you load in when you source("") that file above)
data_longformat <- wf_to_lf(dat_wf)

## (2) calculate point-level statistics
data_summary <- data_longformat %>%
    group_by(habitat, point) %>%
    summarise(abundance = sum(abundance, na.rm=T), 
              n_sp = n())