## Partial script for summarising and plotting your point-count data
##
## You need to change the file name to wherever you have saved your data file 
## and then just run the whole script to format your data from the format you 
## entered it in (wide-format) to a useful long-format summary for plotting. 
##
## Note: you can set your working directory using setwd("..."), where "..." is the 
## directory you want to read files from, or, equivalently, find it manually via 
## the Session > Set working directory > Choose directory tabs in RStudio

# Check students have got the required packages installed
required_packages <- c("ggplot2", "dplyr") 
not_installed <- !(required_packages %in% installed.packages())
if(any(not_installed)) {
    stop(paste0("following packages need installing: ", required_packages[not_installed]))
}

# Check students have setup their working directory properly (by opening the 
# project)
wrong_wd <- !("APS278_practical.Rproj" %in% list.files())
if(wrong_wd) {
    wd_message <- 
        "Your working directory is not set correctly and R therefore can't find 
    the files. Before opening plotting_script.R, you need to first need to open 
    the R project (which will set your working directory). Either double click 
    on it in the file, or, from Rstudio, go to File -> Open Project and then find 
    and open it"
    stop(paste(strwrap(wd_message), collapse="\n"))
}

# packages
library(ggplot2); library(dplyr)

# this is loading a function that is provided in another R script. You don't 
# need to understand the technical details of this, but feel free to look at it
# if of interest
source("code/functions.R")

## (1) read in csv file (wide-format)
dat_wf <- read.csv("files/completed_datatable.csv", header = T, 
                   colClasses = c(rep("integer", 11), "character")) %>% 
    as_tibble

# Previously some students had an issue that I've not been able to replicate, 
# where "i.." is appended to start of "Morphospecies". Not sure why this happens, 
# but this fixes it
names(dat_wf)[1] <- "Morphospecies"

# convert to a long-format dataframe (note: this is a function I have written 
# for you, that you load in when you source("") that file above)
data_longformat <- wf_to_lf(dat_wf)

## (2) calculate point-level statistics
data_summary <- data_longformat %>%
    group_by(habitat, point) %>%
    summarise(abundance = sum(abundance, na.rm=T), 
              n_sp = n())