## Partial script for plotting your point-count data

# packages
library(ggplot2); library(dplyr)

# this runs a script that will reformat your data from wide-format to long-format
# for plotting, and loads a function to use later. 
source("code/data_formatting.R")

# This should have opened a new tab called 'dat_wf': check it out. Does it look 
# as you expect? If you are getting error messages at this stage it is because you 
# have either (a) made entries in cells where there should be none, (b) entered 
# characters into the columns that should only have numbers, (c) made entries 
# outside of the columns and rows provided, or (d) haven't saved your data table 
# as completed_datatable.csv into the "files" directory. If this happens
# you will need to go back and edit your dataframe, resave it, and try again. 

# You now have a data_summary table that summarises the number of individuals
# and species per point
data_summary

# You now have a long-format dataframe that contains the id of each species observed 
# on each point, and the number of individuals you heard of that species
data_longformat

# these two dataframes contain all the information you need for the tasks. 

# Tasks
# task 1: what is the average number of species on a point in each habitat? 
data_summary %>%
    summarise(average = mean(n_sp))

# task2: produce plot of point-level species richness by habitat type
# e.g. histogram, dotplot, points (+horizontal jittering)
p1 <- ggplot(data_summary, aes(habitat, n_sp, fill=habitat)) + 
    geom_jitter(height=0, width=.1, pch=21, size=2) +
    guides(fill="none") +
    scale_y_continuous(breaks=seq(0, 50, 2)) +
    scale_fill_manual(values=c("aquamarine4", "indianred")) +
    labs(x="Habitat", y="Species richness") +
    theme(aspect.ratio = .9, 
          axis.text = element_text(colour="black")) 

# task 3: how many species do you observe in total in each different habitat type?
# note: you will need to refer back to your data_longformat table here
data_longformat %>% 
    filter(complete.cases(.)) %>%
    group_by(habitat) %>%
    summarise(length(unique(id_species)))

# task 4: are there more species in one habitat vs the other than we would expect
# by chance? To do this we need to plot rarefaction curves for your samples

# calculate rarefaction curves
# calculate_rcurve is a function that I have written for you: it will
# return a dataframe of number of individuals sampled ("m" column) and the 
# expected species richness in this sample, as well as some upper and lower (95%)
# bounds on this, 'upr', and 'lwr,.
preds_forest <- calculate_rcurve(data_longformat, habitat_type = "Forest")  
preds_pasture <- calculate_rcurve(data_longformat, habitat_type = "Pasture")  
# bind your predictions for pasture and forest together into a single dataframe
preds_both <- bind_rows(preds_forest, preds_pasture)

# plot these rarefaction curves
p2 <- ggplot(preds_both, aes(m, S_exp, ymin=lwr, ymax=upr, fill=habitat)) + 
    geom_line(aes(col=habitat)) + 
    geom_ribbon(alpha=.2) +
    scale_fill_manual(values=c("aquamarine4", "indianred")) +
    scale_colour_manual(values=c("aquamarine4", "indianred")) +
    labs(x = "Number of individuals sampled", y="Number of species") +
    theme(axis.text = element_text(colour="black"))  +
    guides(fill="none", col="none")

p3 <- ggplot(preds_both, aes(m, S_exp, ymin=lwr, ymax=upr, fill=habitat)) + 
    geom_line(aes(col=habitat)) + 
    geom_ribbon(alpha=.2) +
    scale_fill_manual(values=c("aquamarine4", NA)) +
    scale_colour_manual(values=c("aquamarine4", "indianred")) +
    labs(x = "Number of individuals sampled", y="Number of species") +
    theme(axis.text = element_text(colour="black")) +
    guides(fill="none", col="none")


# save figures
ggsave("species_richness_point.png", p1 + theme(axis.text.y = element_blank()))

# plots_all <- egg::ggarrange(p1, ggplot() + geom_blank() + theme_void(), p2, p3)
png("rarefaction_curve.png", res=200, height=120, width=200, units="mm")
egg::ggarrange(p2 + theme(axis.text.y = element_blank()), 
       p3 + theme(axis.text.y = element_blank(), axis.title.y=element_blank()), ncol=2)
dev.off()
